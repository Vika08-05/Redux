export const counterPlus = () => {
    return {
        type: "PLUS",
    }
} 
export const counterMinus = () => {
    return {
        type: "MINUS",
    }
} 
export const counterTwo = () => {
    return {
        type: "OnTwo",
    }
} 
export const PlusTwo = () => {
    return {
        type: "PlusTwo",
    }
} 
export const InTwo = () => {
    return {
        type: "InTwo",
    }
} 
export const MinusTwo = () => {
    return {
        type: "MinusTwo",
    }
} 
export const Zero= () => {
    return {
        type: "Zero",
    }
} 
